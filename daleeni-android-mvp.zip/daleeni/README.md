# دليني (Daleeni)
1. Run tools/build_iraq_maps.sh. It needs tilemaker's config-openmaptiles.json and process-openmaptiles.lua copied into tools/tilemaker/ as config.json and process.lua.
2. Copy a province file (e.g. baghdad.mbtiles) to the phone: Android/data/com.daleeni.maps/files/maps/
3. Create a Supabase project, run supabase/schema.sql, put the URL and anon key in app/build.gradle.kts.
4. Open this folder in Android Studio and Run.
Without an .mbtiles file the app shows an online demo map.
