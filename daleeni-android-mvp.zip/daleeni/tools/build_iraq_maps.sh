#!/usr/bin/env bash
# Daleeni (دليني) - Build offline map packages per Iraqi governorate
# Requirements: osmium-tool, tilemaker, curl
#   Ubuntu: sudo apt install osmium-tool tilemaker curl
#
# Usage: ./build_iraq_maps.sh
# Output: ./out/<governorate>.mbtiles  (+ .osm.pbf for routing)

set -euo pipefail

WORK_DIR="./work"
OUT_DIR="./out"
PBF_URL="https://download.geofabrik.de/asia/iraq-latest.osm.pbf"
PBF_FILE="$WORK_DIR/iraq-latest.osm.pbf"

mkdir -p "$WORK_DIR" "$OUT_DIR"

# 1) Download Iraq extract
if [ ! -f "$PBF_FILE" ]; then
  echo ">> Downloading Iraq OSM data..."
  curl -L -o "$PBF_FILE" "$PBF_URL"
fi

# 2) Governorates as approximate bounding boxes: name|min_lon,min_lat,max_lon,max_lat
# NOTE: boxes overlap slightly at borders. Fine for MVP; replace with
# real admin-boundary polygons later (osmium extract -p polygon.geojson).
GOVERNORATES=(
  "baghdad|44.0,33.0,44.7,33.65"
  "nineveh|40.9,35.2,43.7,37.1"
  "basra|46.6,29.0,48.6,31.3"
  "dhi_qar|45.3,30.5,47.2,32.0"
  "maysan|46.4,31.2,47.9,32.6"
  "wasit|44.8,32.0,46.8,33.5"
  "babil|44.1,32.0,45.2,33.2"
  "karbala|43.3,31.9,44.5,33.0"
  "najaf|42.0,29.1,45.0,32.2"
  "qadisiyah|44.4,31.4,45.6,32.4"
  "muthanna|44.0,29.1,46.2,31.5"
  "anbar|38.8,30.8,44.5,34.8"
  "diyala|44.4,33.0,46.2,34.6"
  "saladin|42.8,33.5,44.5,35.3"
  "kirkuk|43.3,34.8,44.7,35.9"
  "erbil|43.3,35.5,45.0,37.2"
  "sulaymaniyah|44.5,34.4,46.3,36.3"
  "duhok|42.2,36.4,44.0,37.4"
)

# 3) Extract each governorate, then build vector tiles
for entry in "${GOVERNORATES[@]}"; do
  name="${entry%%|*}"
  bbox="${entry##*|}"
  pbf="$OUT_DIR/$name.osm.pbf"
  mbtiles="$OUT_DIR/$name.mbtiles"

  echo ">> [$name] extracting bbox $bbox"
  osmium extract --bbox "$bbox" --strategy complete_ways \
    "$PBF_FILE" -o "$pbf" --overwrite

  echo ">> [$name] building vector tiles"
  tilemaker --input "$pbf" --output "$mbtiles" \
    --bbox "$bbox" \
    --config tilemaker/config.json \
    --process tilemaker/process.lua
done

echo ">> Done. Packages in $OUT_DIR"
du -sh "$OUT_DIR"/*.mbtiles
