-- Run in Supabase SQL editor
create table public.reports (
  id         uuid primary key default gen_random_uuid(),
  type       text not null check (type in ('checkpoint','traffic','accident','roadwork','closed','bump','camera')),
  lat        double precision not null check (lat between 28 and 38),
  lng        double precision not null check (lng between 38 and 50),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '2 hours'
);
create index reports_expires_idx on public.reports (expires_at);

alter table public.reports enable row level security;
create policy "anyone can read active reports" on public.reports for select using (expires_at > now());
create policy "anyone can insert reports"      on public.reports for insert with check (true);
