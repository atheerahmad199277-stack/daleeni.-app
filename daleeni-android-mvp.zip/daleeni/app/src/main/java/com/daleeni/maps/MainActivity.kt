package com.daleeni.maps

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.location.LocationComponentActivationOptions
import org.maplibre.android.location.modes.CameraMode
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.sources.GeoJsonSource

class MainActivity : AppCompatActivity() {

    // key -> (Arabic label, marker color)
    private val types = linkedMapOf(
        "checkpoint" to ("سيطرة" to "#1565C0"),
        "traffic"    to ("زحمة" to "#E53935"),
        "accident"   to ("حادث" to "#B71C1C"),
        "roadwork"   to ("حفرية" to "#FB8C00"),
        "closed"     to ("طريق مقطوع" to "#6A1B9A"),
        "bump"       to ("مطب" to "#FDD835"),
        "camera"     to ("كاميرا" to "#00897B"),
    )

    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            map?.getStyle { enableLocation(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)

        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m ->
            map = m
            m.cameraPosition = CameraPosition.Builder().target(LatLng(33.3152, 44.3661)).zoom(11.0).build()
            m.setStyle(buildStyle()) { style ->
                setupReportsLayer(style)
                if (hasLocationPermission()) enableLocation(style)
                else locationPermission.launch(arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
        }

        findViewById<android.view.View>(R.id.fabReport).setOnClickListener { showReportSheet() }
    }

    /** Uses an offline .mbtiles from app storage if present, otherwise a demo online style. */
    private fun buildStyle(): Style.Builder {
        val dir = getExternalFilesDir("maps")
        val mbtiles = dir?.listFiles { f -> f.extension == "mbtiles" }?.firstOrNull()
        return if (mbtiles != null) {
            val json = assets.open("style_offline.json").bufferedReader().readText()
                .replace("__MBTILES__", mbtiles.absolutePath)
            Style.Builder().fromJson(json)
        } else {
            Style.Builder().fromUri("https://demotiles.maplibre.org/style.json")
        }
    }

    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun enableLocation(style: Style) {
        if (!hasLocationPermission()) return
        val lc = map?.locationComponent ?: return
        lc.activateLocationComponent(LocationComponentActivationOptions.builder(this, style).build())
        lc.isLocationComponentEnabled = true
        lc.cameraMode = CameraMode.TRACKING
    }

    private fun setupReportsLayer(style: Style) {
        style.addSource(GeoJsonSource("reports"))
        style.addLayer(
            CircleLayer("reports-layer", "reports").withProperties(
                circleRadius(9f),
                circleColor(Expression.toColor(Expression.get("color"))),
                circleStrokeColor(Color.WHITE),
                circleStrokeWidth(2f),
            )
        )
    }

    private fun showReportSheet() {
        val sheet = BottomSheetDialog(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 60) }
        col.addView(TextView(this).apply {
            text = getString(R.string.report_title); textSize = 20f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 24)
        })
        types.forEach { (key, v) ->
            col.addView(Button(this).apply {
                text = v.first
                setOnClickListener { sheet.dismiss(); sendReport(key) }
            })
        }
        sheet.setContentView(col)
        sheet.show()
    }

    @SuppressLint("MissingPermission")
    private fun sendReport(type: String) {
        val loc = if (hasLocationPermission()) map?.locationComponent?.lastKnownLocation else null
        if (loc == null) { Toast.makeText(this, R.string.no_location, Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { ReportApi.send(type, loc.latitude, loc.longitude) }.getOrDefault(false) }
            Toast.makeText(this@MainActivity, if (ok) R.string.sent else R.string.failed, Toast.LENGTH_SHORT).show()
            if (ok) refreshReports()
        }
    }

    private suspend fun refreshReports() {
        val reports = withContext(Dispatchers.IO) { runCatching { ReportApi.fetch() }.getOrDefault(emptyList()) }
        val features = reports.joinToString(",") { r ->
            val color = types[r.type]?.second ?: "#757575"
            """{"type":"Feature","properties":{"color":"$color","type":"${r.type}"},"geometry":{"type":"Point","coordinates":[${r.lng},${r.lat}]}}"""
        }
        map?.getStyle { it.getSourceAs<GeoJsonSource>("reports")?.setGeoJson("""{"type":"FeatureCollection","features":[$features]}""") }
    }

    override fun onStart() {
        super.onStart(); mapView.onStart()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) { refreshReports(); delay(30_000) }
            }
        }
    }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
}
