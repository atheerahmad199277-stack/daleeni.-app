plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.daleeni.maps"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.daleeni.maps"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        // Fill these from Supabase > Project Settings > API
        buildConfigField("String", "SUPABASE_URL", "\"https://YOUR_PROJECT.supabase.co\"")
        buildConfigField("String", "SUPABASE_KEY", "\"YOUR_ANON_KEY\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("org.maplibre.gl:android-sdk:11.5.2")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
