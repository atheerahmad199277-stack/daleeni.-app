package com.daleeni.maps

import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.geometry.LatLng
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.cos
import kotlin.math.hypot

data class Place(val title: String, val lat: Double, val lng: Double)
data class Step(
    val type: String, val modifier: String?, val name: String, val exit: Int?,
    val distance: Double, val lat: Double, val lng: Double
)
data class Route(val points: List<LatLng>, val distance: Double, val duration: Double, val steps: List<Step>)

/** Search (Nominatim) and routing (OSRM). Public demo servers: fine for testing, replace with our own servers before launch. */
object GeoApi {
    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Daleeni/0.2 (Android)")
        c.connectTimeout = 10000
        c.readTimeout = 15000
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } finally { c.disconnect() }
    }

    fun search(q: String): List<Place> {
        val txt = get(
            "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=iq&accept-language=ar&q=" +
                URLEncoder.encode(q, "UTF-8")
        ) ?: return emptyList()
        val arr = JSONArray(txt)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Place(o.optString("display_name").split(",").take(3).joinToString("،"), o.getDouble("lat"), o.getDouble("lon"))
        }
    }

    fun route(fromLat: Double, fromLng: Double, toLat: Double, toLng: Double): Route? =
        routes(fromLat, fromLng, toLat, toLng).firstOrNull()

    /** Fastest route first, then up to two alternatives. */
    fun routes(fromLat: Double, fromLng: Double, toLat: Double, toLng: Double): List<Route> {
        val txt = get(
            "https://router.project-osrm.org/route/v1/driving/$fromLng,$fromLat;$toLng,$toLat" +
                "?overview=full&geometries=geojson&steps=true&alternatives=true"
        ) ?: return emptyList()
        val j = JSONObject(txt)
        if (j.optString("code") != "Ok") return emptyList()
        val arr = j.getJSONArray("routes")
        return (0 until arr.length()).map { parseRoute(arr.getJSONObject(it)) }
    }

    private fun parseRoute(r: JSONObject): Route {
        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val pts = (0 until coords.length()).map {
            val c = coords.getJSONArray(it)
            LatLng(c.getDouble(1), c.getDouble(0))
        }
        val steps = ArrayList<Step>()
        val legs = r.getJSONArray("legs")
        for (li in 0 until legs.length()) {
            val st = legs.getJSONObject(li).getJSONArray("steps")
            for (si in 0 until st.length()) {
                val s = st.getJSONObject(si)
                val m = s.getJSONObject("maneuver")
                val loc = m.getJSONArray("location")
                steps.add(
                    Step(
                        m.getString("type"),
                        m.optString("modifier").takeIf { it.isNotEmpty() },
                        s.optString("name"),
                        if (m.has("exit")) m.getInt("exit") else null,
                        s.getDouble("distance"),
                        loc.getDouble(1), loc.getDouble(0)
                    )
                )
            }
        }
        return Route(pts, r.getDouble("distance"), r.getDouble("duration"), steps)
    }
}

object Geo {
    fun dist(a: LatLng, b: LatLng): Double {
        val r = FloatArray(1)
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, r)
        return r[0].toDouble()
    }

    /** Shortest distance (meters) from a point to the route polyline. */
    fun distToRoute(p: LatLng, pts: List<LatLng>): Double {
        val kx = 111320.0 * cos(Math.toRadians(p.latitude))
        val ky = 110540.0
        var best = Double.MAX_VALUE
        for (i in 0 until pts.size - 1) {
            val ax = (pts[i].longitude - p.longitude) * kx
            val ay = (pts[i].latitude - p.latitude) * ky
            val bx = (pts[i + 1].longitude - p.longitude) * kx
            val by = (pts[i + 1].latitude - p.latitude) * ky
            val dx = bx - ax
            val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
            val d = hypot(ax + t * dx, ay + t * dy)
            if (d < best) best = d
        }
        return best
    }
}
