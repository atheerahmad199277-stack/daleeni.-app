package com.daleeni.maps

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.location.LocationComponentActivationOptions
import org.maplibre.android.location.modes.CameraMode
import org.maplibre.android.location.modes.RenderMode
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.sources.GeoJsonSource
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), LocationListener, TextToSpeech.OnInitListener {

    // key -> (Arabic label, marker color)
    private val types = linkedMapOf(
        "checkpoint" to ("سيطرة" to "#1565C0"),
        "traffic"    to ("زحمة" to "#E53935"),
        "accident"   to ("حادث" to "#B71C1C"),
        "roadwork"   to ("حفرية" to "#FB8C00"),
        "closed"     to ("طريق مقطوع" to "#6A1B9A"),
        "bump"       to ("مطب" to "#F9A825"),
        "camera"     to ("كاميرا" to "#00897B"),
    )
    private val emoji = mapOf(
        "checkpoint" to "🚓", "traffic" to "🚗", "accident" to "💥",
        "roadwork" to "🚧", "closed" to "⛔", "bump" to "⚠️", "camera" to "📷"
    )
    private val emptyGeo = """{"type":"FeatureCollection","features":[]}"""

    private lateinit var mapView: MapView
    private lateinit var searchCard: View
    private lateinit var searchInput: EditText
    private lateinit var fromInput: EditText
    private lateinit var results: LinearLayout
    private lateinit var banner: View
    private lateinit var bannerIcon: ImageView
    private lateinit var bannerDist: TextView
    private lateinit var bannerText: TextView
    private lateinit var routeCard: View
    private lateinit var routeEta: TextView
    private lateinit var routeDist: TextView
    private lateinit var btnStart: Button
    private lateinit var btnCancel: Button
    private lateinit var speedCard: View
    private lateinit var speedText: TextView
    private lateinit var fabColumn: View
    private lateinit var homeBar: View
    private lateinit var altRow: LinearLayout
    private var map: MapLibreMap? = null

    private var route: Route? = null
    private var dest: LatLng? = null
    private var customFrom: LatLng? = null
    private var activeField = 1
    private var routes: List<Route> = emptyList()
    private var selected = 0
    private var navigating = false
    private var nextIdx = 1
    private var announcedFar = -1
    private var offCount = 0
    private var lastReroute = 0L
    private var lastLoc: Location? = null
    private var listening = false
    private var reports: List<Report> = emptyList()
    private val warned = HashSet<String>()
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            map?.getStyle { enableLocation(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)

        searchCard = findViewById(R.id.searchCard)
        searchInput = findViewById(R.id.searchInput)
        fromInput = findViewById(R.id.fromInput)
        results = findViewById(R.id.results)
        banner = findViewById(R.id.banner)
        bannerIcon = findViewById(R.id.bannerIcon)
        bannerDist = findViewById(R.id.bannerDist)
        bannerText = findViewById(R.id.bannerText)
        routeCard = findViewById(R.id.routeCard)
        routeEta = findViewById(R.id.routeEta)
        routeDist = findViewById(R.id.routeDist)
        btnStart = findViewById(R.id.btnStart)
        btnCancel = findViewById(R.id.btnCancel)
        speedCard = findViewById(R.id.speedCard)
        speedText = findViewById(R.id.speedText)
        fabColumn = findViewById(R.id.fabColumn)
        homeBar = findViewById(R.id.homeBar)
        altRow = findViewById(R.id.altRow)
        homeBar.setOnClickListener { openSearch() }
        homeBar.post { updateOverlays() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (route != null || searchCard.visibility == View.VISIBLE) clearRoute()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        tts = TextToSpeech(this, this)

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        fromInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (fromInput.text.isBlank()) { customFrom = null; hideKeyboard(); planRoute() } else doSearch()
                true
            } else false
        }
        fromInput.setOnFocusChangeListener { _, has -> if (has) activeField = 0 }
        searchInput.setOnFocusChangeListener { _, has -> if (has) activeField = 1 }
        findViewById<View>(R.id.btnSwap).setOnClickListener { swapPlaces() }
        btnStart.setOnClickListener { startNav() }
        btnCancel.setOnClickListener { clearRoute() }
        findViewById<View>(R.id.fabReport).setOnClickListener { showReportSheet() }
        findViewById<View>(R.id.btnMyLoc).setOnClickListener {
            val here = currentLatLng()
            if (here != null) map?.animateCamera(CameraUpdateFactory.newLatLngZoom(here, 15.0))
            else toast(R.string.no_location)
        }

        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m ->
            map = m
            m.cameraPosition = CameraPosition.Builder().target(LatLng(33.3152, 44.3661)).zoom(11.0).build()
            m.addOnMapLongClickListener { p -> chooseDest(p); true }
            m.setStyle(buildStyle()) { style ->
                setupLayers(style)
                if (hasLocationPermission()) enableLocation(style)
                else locationPermission.launch(arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val res = tts?.setLanguage(Locale("ar"))
            ttsReady = res != null && res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun speak(t: String) {
        if (ttsReady) tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "nav")
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    /** Uses an offline .mbtiles from app storage if present, otherwise an online OSM style. */
    private fun buildStyle(): Style.Builder {
        val dir = getExternalFilesDir("maps")
        val mbtiles = dir?.listFiles { f -> f.extension == "mbtiles" }?.firstOrNull()
        return if (mbtiles != null) {
            val json = assets.open("style_offline.json").bufferedReader().readText()
                .replace("__MBTILES__", mbtiles.absolutePath)
            Style.Builder().fromJson(json)
        } else {
            Style.Builder().fromUri("https://tiles.openfreemap.org/styles/liberty")
        }
    }

    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun enableLocation(style: Style) {
        if (!hasLocationPermission()) return
        val lc = map?.locationComponent ?: return
        lc.activateLocationComponent(LocationComponentActivationOptions.builder(this, style).build())
        lc.isLocationComponentEnabled = true
        lc.cameraMode = CameraMode.TRACKING
        startUpdates()
    }

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        if (listening || !hasLocationPermission()) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 1000L, 0f, this)
        }
        listening = true
    }

    private fun setupLayers(style: Style) {
        style.addSource(GeoJsonSource("route", emptyGeo))
        style.addSource(GeoJsonSource("dest", emptyGeo))
        style.addSource(GeoJsonSource("reports", emptyGeo))
        style.addSource(GeoJsonSource("alt", emptyGeo))
        style.addLayer(LineLayer("alt-line", "alt").withProperties(
            lineColor("#9AA8AB"), lineWidth(6f),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(LineLayer("route-casing", "route").withProperties(
            lineColor("#075B66"), lineWidth(10f),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(LineLayer("route-line", "route").withProperties(
            lineColor("#1AA6B7"), lineWidth(6f),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(CircleLayer("dest-layer", "dest").withProperties(
            circleRadius(10f), circleColor("#F5A524"),
            circleStrokeColor(Color.WHITE), circleStrokeWidth(3f)))
        style.addLayer(CircleLayer("reports-layer", "reports").withProperties(
            circleRadius(9f),
            circleColor(Expression.toColor(Expression.get("color"))),
            circleStrokeColor(Color.WHITE), circleStrokeWidth(2f)))
    }

    // ---------- Search & routing ----------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    private fun doSearch() {
        val q = (if (activeField == 0) fromInput else searchInput).text.toString().trim()
        if (q.isEmpty()) return
        hideKeyboard()
        lifecycleScope.launch {
            val places = withContext(Dispatchers.IO) { runCatching { GeoApi.search(q) }.getOrDefault(emptyList()) }
            results.removeAllViews()
            if (places.isEmpty()) {
                results.visibility = View.GONE
                toast(R.string.no_results)
                return@launch
            }
            places.forEach { p ->
                val parts = p.title.split("،")
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(22), dp(14), dp(22), dp(14))
                    setOnClickListener { pickPlace(LatLng(p.lat, p.lng), parts.first()) }
                }
                row.addView(TextView(this@MainActivity).apply {
                    text = parts.first()
                    textSize = 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(ContextCompat.getColor(this@MainActivity, R.color.ink))
                })
                if (parts.size > 1) row.addView(TextView(this@MainActivity).apply {
                    text = parts.drop(1).joinToString("،")
                    textSize = 13f
                    setTextColor(ContextCompat.getColor(this@MainActivity, R.color.gray))
                })
                results.addView(row)
            }
            results.visibility = View.VISIBLE
        }
    }

    private fun currentLatLng(): LatLng? {
        val l = lastLoc ?: runCatching { map?.locationComponent?.lastKnownLocation }.getOrNull()
        return l?.let { LatLng(it.latitude, it.longitude) }
    }

    /** A place was chosen from search results for the active field (from / to). */
    private fun pickPlace(ll: LatLng, name: String) {
        if (activeField == 0) { customFrom = ll; fromInput.setText(name) }
        else { dest = ll; searchInput.setText(name) }
        results.visibility = View.GONE
        fromInput.clearFocus()
        searchInput.clearFocus()
        hideKeyboard()
        planRoute()
    }

    /** Long-press on the map sets the destination. */
    private fun chooseDest(to: LatLng) {
        dest = to
        searchInput.setText("نقطة على الخريطة")
        results.visibility = View.GONE
        planRoute()
    }

    private fun swapPlaces() {
        val d = dest ?: return
        val f = customFrom ?: currentLatLng() ?: return
        val toText = searchInput.text.toString()
        val fromText = fromInput.text.toString().ifBlank { "موقعي الحالي" }
        customFrom = d
        dest = f
        fromInput.setText(toText)
        searchInput.setText(fromText)
        planRoute()
    }

    private fun openSearch() {
        homeBar.visibility = View.GONE
        searchCard.visibility = View.VISIBLE
        searchInput.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        updateOverlays()
    }

    private fun planRoute() {
        val to = dest ?: return
        val from = customFrom ?: currentLatLng()
        if (from == null) { toast(R.string.no_location); return }
        lifecycleScope.launch {
            val rs = withContext(Dispatchers.IO) {
                runCatching { GeoApi.routes(from.latitude, from.longitude, to.latitude, to.longitude) }
                    .getOrDefault(emptyList())
            }
            if (rs.isEmpty()) { toast(R.string.no_route); return@launch }
            routes = rs
            selected = 0
            route = rs[0]
            homeBar.visibility = View.GONE
            searchCard.visibility = View.VISIBLE
            showSelected(true)
            routeCard.visibility = View.VISIBLE
            btnStart.visibility = View.VISIBLE
            routeCard.post { updateOverlays() }
        }
    }

    private fun showSelected(fit: Boolean) {
        val r = route ?: return
        val to = dest ?: return
        drawRoute(r, to)
        drawAlts()
        setRoute(r.distance, r.duration)
        buildAltChips()
        if (fit) fitRoute(r)
    }

    private fun selectRoute(i: Int) {
        if (i !in routes.indices) return
        selected = i
        route = routes[i]
        showSelected(false)
    }

    private fun drawAlts() {
        val feats = routes.filterIndexed { i, _ -> i != selected }.joinToString(",") { r ->
            val coords = r.points.joinToString(",") { "[${it.longitude},${it.latitude}]" }
            """{"type":"Feature","properties":{},"geometry":{"type":"LineString","coordinates":[$coords]}}"""
        }
        map?.getStyle {
            it.getSourceAs<GeoJsonSource>("alt")?.setGeoJson("""{"type":"FeatureCollection","features":[$feats]}""")
        }
    }

    private fun buildAltChips() {
        altRow.removeAllViews()
        if (routes.size < 2) { altRow.visibility = View.GONE; return }
        altRow.visibility = View.VISIBLE
        routes.forEachIndexed { i, r ->
            val on = i == selected
            val mins = ceil(r.duration / 60).toInt()
            val chip = TextView(this).apply {
                text = if (i == 0) "$mins د · الأسرع" else "$mins د"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setTextColor(if (on) Color.WHITE else ContextCompat.getColor(context, R.color.ink))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(if (on) ContextCompat.getColor(context, R.color.teal) else Color.parseColor("#E8EEEF"))
                }
                setOnClickListener { selectRoute(i) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            altRow.addView(chip, lp)
        }
    }

    private fun drawRoute(r: Route, to: LatLng) {
        val coords = r.points.joinToString(",") { "[${it.longitude},${it.latitude}]" }
        val line = """{"type":"Feature","properties":{},"geometry":{"type":"LineString","coordinates":[$coords]}}"""
        val pt = """{"type":"Feature","properties":{},"geometry":{"type":"Point","coordinates":[${to.longitude},${to.latitude}]}}"""
        map?.getStyle {
            it.getSourceAs<GeoJsonSource>("route")?.setGeoJson(line)
            it.getSourceAs<GeoJsonSource>("dest")?.setGeoJson(pt)
        }
    }

    private fun fitRoute(r: Route) {
        runCatching {
            val b = LatLngBounds.Builder()
            r.points.forEach { b.include(it) }
            map?.animateCamera(CameraUpdateFactory.newLatLngBounds(b.build(), 100, 260, 100, 420), 800)
        }
    }

    private fun fmtDist(m: Double): String =
        if (m < 1000) "${((m / 10).roundToInt() * 10).coerceAtLeast(10)} متر"
        else String.format(Locale.US, "%.1f كم", m / 1000)

    private fun summary(dist: Double, dur: Double) = "${fmtDist(dist)} · ${ceil(dur / 60).toInt()} دقيقة"

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun setBanner(s: Step, d: Double?) {
        bannerIcon.setImageResource(iconFor(s))
        bannerDist.text = if (d != null) fmtDist(d) else ""
        bannerText.text = Ar.text(s)
    }

    private fun iconFor(s: Step): Int = when {
        s.type == "arrive" -> R.drawable.ic_place
        s.modifier == "uturn" || s.modifier?.contains("left") == true -> R.drawable.ic_dir_left
        s.modifier?.contains("right") == true -> R.drawable.ic_dir_right
        else -> R.drawable.ic_dir_straight
    }

    private fun setRoute(dist: Double, dur: Double) {
        routeEta.text = "${ceil(dur / 60).toInt()} دقيقة"
        val arrive = Calendar.getInstance().apply { add(Calendar.SECOND, dur.toInt()) }
        routeDist.text = fmtDist(dist) + " · وصول " + SimpleDateFormat("HH:mm", Locale.US).format(arrive.time)
    }

    /** Keeps the floating buttons and speed bubble above the route card. */
    private fun updateOverlays() {
        val h = when {
            routeCard.visibility == View.VISIBLE -> routeCard.height + dp(12)
            homeBar.visibility == View.VISIBLE -> homeBar.height + dp(12)
            else -> 0
        }
        fabColumn.translationY = -h.toFloat()
        speedCard.translationY = -h.toFloat()
    }

    // ---------- Navigation ----------

    private fun startNav() {
        val to = dest
        val here = currentLatLng()
        if (customFrom != null && to != null && here != null) {
            // Chosen start differs from where we are: navigate from the current position.
            lifecycleScope.launch {
                val nr = withContext(Dispatchers.IO) {
                    runCatching { GeoApi.route(here.latitude, here.longitude, to.latitude, to.longitude) }.getOrNull()
                }
                if (nr != null) { route = nr; drawRoute(nr, to) }
                beginNav()
            }
        } else beginNav()
    }

    private fun beginNav() {
        val r = route ?: return
        navigating = true
        nextIdx = 1
        announcedFar = -1
        offCount = 0
        warned.clear()
        routes = emptyList()
        altRow.visibility = View.GONE
        map?.getStyle { it.getSourceAs<GeoJsonSource>("alt")?.setGeoJson(emptyGeo) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        searchCard.visibility = View.GONE
        btnStart.visibility = View.GONE
        banner.visibility = View.VISIBLE
        speedCard.visibility = View.VISIBLE
        speedText.text = "0"
        btnCancel.text = getString(R.string.end_nav)
        btnCancel.setTextColor(ContextCompat.getColor(this, R.color.danger))
        if (!ttsReady) toast(R.string.no_tts)
        if (r.steps.isNotEmpty()) {
            setBanner(r.steps.first(), null)
            speak(Ar.text(r.steps.first()))
        }
        routeCard.post { updateOverlays() }
        runCatching {
            map?.locationComponent?.apply {
                renderMode = RenderMode.GPS
                cameraMode = CameraMode.TRACKING_GPS
                zoomWhileTracking(17.0)
                tiltWhileTracking(45.0)
            }
        }
    }

    private fun clearRoute() {
        navigating = false
        route = null
        dest = null
        customFrom = null
        fromInput.setText("")
        searchInput.setText("")
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        map?.getStyle {
            it.getSourceAs<GeoJsonSource>("route")?.setGeoJson(emptyGeo)
            it.getSourceAs<GeoJsonSource>("dest")?.setGeoJson(emptyGeo)
            it.getSourceAs<GeoJsonSource>("alt")?.setGeoJson(emptyGeo)
        }
        routes = emptyList()
        routeCard.visibility = View.GONE
        banner.visibility = View.GONE
        altRow.visibility = View.GONE
        searchCard.visibility = View.GONE
        homeBar.visibility = View.VISIBLE
        hideKeyboard()
        btnCancel.text = getString(R.string.cancel)
        btnCancel.setTextColor(ContextCompat.getColor(this, R.color.teal))
        updateOverlays()
        runCatching {
            map?.locationComponent?.apply {
                renderMode = RenderMode.NORMAL
                cameraMode = CameraMode.TRACKING
            }
        }
    }

    override fun onLocationChanged(loc: Location) {
        lastLoc = loc
        speedText.text = "${(loc.speed * 3.6f).roundToInt()}"
        if (speedCard.visibility != View.VISIBLE) { speedCard.visibility = View.VISIBLE; updateOverlays() }
        if (!navigating) return
        if (loc.hasAccuracy() && loc.accuracy > 60f) return
        val r = route ?: return
        val here = LatLng(loc.latitude, loc.longitude)
        speedText.text = "${(loc.speed * 3.6f).roundToInt()}"

        // Off-route -> reroute
        if (Geo.distToRoute(here, r.points) > 60.0) {
            offCount++
            val now = System.currentTimeMillis()
            if (offCount >= 3 && now - lastReroute > 10_000) reroute(here)
        } else offCount = 0

        // Steps
        if (nextIdx < r.steps.size) {
            val s = r.steps[nextIdx]
            val d = Geo.dist(here, LatLng(s.lat, s.lng))
            setBanner(s, d)

            var remaining = d
            for (k in nextIdx until r.steps.size) remaining += r.steps[k].distance
            val secs = remaining * (r.duration / r.distance.coerceAtLeast(1.0))
            setRoute(remaining, secs)

            if (s.type == "arrive") {
                if (d <= 400 && announcedFar != nextIdx) {
                    announcedFar = nextIdx
                    speak("وجهتك بعد ${((d / 50).roundToInt() * 50).coerceAtLeast(50)} متر")
                }
                if (d <= 30) {
                    speak("وصلت إلى وجهتك")
                    Toast.makeText(this, "وصلت إلى وجهتك", Toast.LENGTH_LONG).show()
                    clearRoute()
                    return
                }
            } else {
                if (d <= 400 && announcedFar != nextIdx) {
                    announcedFar = nextIdx
                    speak("بعد ${((d / 50).roundToInt() * 50).coerceAtLeast(50)} متر ${Ar.text(s)}")
                }
                if (d <= 35) {
                    speak(Ar.text(s))
                    nextIdx++
                }
            }
        }

        checkReportsAhead(here, loc)
    }

    private fun reroute(here: LatLng) {
        val to = route?.points?.lastOrNull() ?: return
        lastReroute = System.currentTimeMillis()
        offCount = 0
        speak("جاري إعادة حساب الطريق")
        lifecycleScope.launch {
            val nr = withContext(Dispatchers.IO) {
                runCatching { GeoApi.route(here.latitude, here.longitude, to.latitude, to.longitude) }.getOrNull()
            }
            if (nr != null && navigating) {
                route = nr
                nextIdx = 1
                announcedFar = -1
                drawRoute(nr, to)
            }
        }
    }

    private fun checkReportsAhead(here: LatLng, loc: Location) {
        for (rep in reports) {
            if (rep.id in warned) continue
            if (Geo.dist(here, LatLng(rep.lat, rep.lng)) > 350.0) continue
            if (loc.hasBearing() && loc.speed > 2f) {
                val t = Location("report").apply { latitude = rep.lat; longitude = rep.lng }
                val diff = abs(((loc.bearingTo(t) - loc.bearing + 540f) % 360f) - 180f)
                if (diff > 70f) continue
            }
            warned.add(rep.id)
            speak("${types[rep.type]?.first ?: "بلاغ"} أمامك")
        }
    }

    // ---------- Reports ----------

    private fun showReportSheet() {
        val ink = ContextCompat.getColor(this, R.color.ink)
        val sheet = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        root.addView(TextView(this).apply {
            text = getString(R.string.report_title)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
            setPadding(dp(4), 0, 0, dp(16))
        })
        val grid = GridLayout(this).apply { columnCount = 3 }
        types.forEach { (key, v) ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { sheet.dismiss(); sendReport(key) }
            }
            val dot = TextView(this).apply {
                text = emoji[key]
                textSize = 26f
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(v.second))
                }
            }
            tile.addView(dot, LinearLayout.LayoutParams(dp(64), dp(64)))
            tile.addView(TextView(this).apply {
                text = v.first
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(ink)
                setPadding(0, dp(6), 0, 0)
            })
            val lp = GridLayout.LayoutParams()
            lp.width = 0
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            grid.addView(tile, lp)
        }
        root.addView(grid)
        sheet.setContentView(root)
        sheet.show()
    }

    private fun sendReport(type: String) {
        val here = currentLatLng()
        if (here == null) { toast(R.string.no_location); return }
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { ReportApi.send(type, here.latitude, here.longitude) }.getOrDefault(false)
            }
            Toast.makeText(this@MainActivity, if (ok) R.string.sent else R.string.failed, Toast.LENGTH_SHORT).show()
            if (ok) refreshReports()
        }
    }

    private suspend fun refreshReports() {
        reports = withContext(Dispatchers.IO) { runCatching { ReportApi.fetch() }.getOrDefault(emptyList()) }
        val features = reports.joinToString(",") { r ->
            val color = types[r.type]?.second ?: "#757575"
            """{"type":"Feature","properties":{"color":"$color","type":"${r.type}"},"geometry":{"type":"Point","coordinates":[${r.lng},${r.lat}]}}"""
        }
        map?.getStyle { it.getSourceAs<GeoJsonSource>("reports")?.setGeoJson("""{"type":"FeatureCollection","features":[$features]}""") }
    }

    // ---------- Location listener boilerplate ----------
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    // ---------- Lifecycle ----------
    override fun onStart() {
        super.onStart(); mapView.onStart()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) { refreshReports(); delay(30_000) }
            }
        }
    }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() {
        runCatching { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this) }
        tts?.shutdown()
        mapView.onDestroy()
        super.onDestroy()
    }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
}
