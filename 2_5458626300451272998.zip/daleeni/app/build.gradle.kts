plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.daleeni.maps"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.daleeni.maps"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        // Fill these from Supabase > Project Settings > API
        buildConfigField("String", "SUPABASE_URL", "\"https://jlwpmrakhxpcrdkefrqs.supabase.co\"")
        buildConfigField("String", "SUPABASE_KEY", "\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impsd3BtcmFraHhwY3Jka2VmcnFzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ1NDM5NDMsImV4cCI6MjExMDExOTk0M30.mnhwTetDEQslPtQr6TGYkEekdcjGiFmXDCXOvcCgok4\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("org.maplibre.gl:android-sdk:11.5.2")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
