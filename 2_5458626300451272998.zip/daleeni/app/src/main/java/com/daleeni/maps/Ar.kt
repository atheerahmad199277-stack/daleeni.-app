package com.daleeni.maps

/** Arabic turn-by-turn phrases. */
object Ar {
    private fun side(m: String?): String = when (m) {
        "left" -> "يسار"
        "right" -> "يمين"
        "slight left" -> "يسار قليلاً"
        "slight right" -> "يمين قليلاً"
        "sharp left" -> "يسار بحدة"
        "sharp right" -> "يمين بحدة"
        else -> ""
    }

    fun text(s: Step): String {
        val to = if (s.name.isNotBlank()) " إلى ${s.name}" else ""
        return when (s.type) {
            "depart" -> if (s.name.isNotBlank()) "انطلق على ${s.name}" else "انطلق"
            "arrive" -> "وصلت إلى وجهتك"
            "turn", "continue", "new name", "end of road" -> when (s.modifier) {
                "straight", null -> "استمر للأمام$to"
                "uturn" -> "استدر للخلف"
                else -> "انعطف ${side(s.modifier)}$to"
            }
            "merge" -> "ادمج مع الطريق"
            "on ramp", "off ramp" -> "اسلك المنحدر ${side(s.modifier)}".trim()
            "fork" -> "خذ المسار ${side(s.modifier)}".trim()
            "roundabout", "rotary", "roundabout turn" ->
                if (s.exit != null) "ادخل الدوار وخذ المخرج رقم ${s.exit}" else "ادخل الدوار"
            "exit roundabout", "exit rotary" -> "اخرج من الدوار"
            else -> "استمر للأمام"
        }
    }
}
