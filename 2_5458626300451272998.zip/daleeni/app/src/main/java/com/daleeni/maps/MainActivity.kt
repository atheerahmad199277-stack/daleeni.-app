package com.daleeni.maps

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.location.LocationComponentActivationOptions
import org.maplibre.android.location.modes.CameraMode
import org.maplibre.android.location.modes.RenderMode
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.sources.GeoJsonSource
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), LocationListener, TextToSpeech.OnInitListener {

    // key -> (Arabic label, marker color)
    private val types = linkedMapOf(
        "checkpoint" to ("سيطرة" to "#1565C0"),
        "traffic"    to ("زحمة" to "#E53935"),
        "accident"   to ("حادث" to "#B71C1C"),
        "roadwork"   to ("حفرية" to "#FB8C00"),
        "closed"     to ("طريق مقطوع" to "#6A1B9A"),
        "bump"       to ("مطب" to "#FDD835"),
        "camera"     to ("كاميرا" to "#00897B"),
    )
    private val emptyGeo = """{"type":"FeatureCollection","features":[]}"""

    private lateinit var mapView: MapView
    private lateinit var searchCard: View
    private lateinit var searchInput: EditText
    private lateinit var results: LinearLayout
    private lateinit var banner: TextView
    private lateinit var routeCard: View
    private lateinit var routeInfo: TextView
    private lateinit var btnStart: Button
    private lateinit var btnCancel: Button
    private lateinit var speedText: TextView
    private var map: MapLibreMap? = null

    private var route: Route? = null
    private var navigating = false
    private var nextIdx = 1
    private var announcedFar = -1
    private var offCount = 0
    private var lastReroute = 0L
    private var lastLoc: Location? = null
    private var listening = false
    private var reports: List<Report> = emptyList()
    private val warned = HashSet<String>()
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            map?.getStyle { enableLocation(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)

        searchCard = findViewById(R.id.searchCard)
        searchInput = findViewById(R.id.searchInput)
        results = findViewById(R.id.results)
        banner = findViewById(R.id.banner)
        routeCard = findViewById(R.id.routeCard)
        routeInfo = findViewById(R.id.routeInfo)
        btnStart = findViewById(R.id.btnStart)
        btnCancel = findViewById(R.id.btnCancel)
        speedText = findViewById(R.id.speedText)

        tts = TextToSpeech(this, this)

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        btnStart.setOnClickListener { startNav() }
        btnCancel.setOnClickListener { clearRoute() }
        findViewById<View>(R.id.fabReport).setOnClickListener { showReportSheet() }

        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m ->
            map = m
            m.cameraPosition = CameraPosition.Builder().target(LatLng(33.3152, 44.3661)).zoom(11.0).build()
            m.addOnMapLongClickListener { p -> chooseDest(p); true }
            m.setStyle(buildStyle()) { style ->
                setupLayers(style)
                if (hasLocationPermission()) enableLocation(style)
                else locationPermission.launch(arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val res = tts?.setLanguage(Locale("ar"))
            ttsReady = res != null && res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun speak(t: String) {
        if (ttsReady) tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "nav")
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    /** Uses an offline .mbtiles from app storage if present, otherwise an online OSM style. */
    private fun buildStyle(): Style.Builder {
        val dir = getExternalFilesDir("maps")
        val mbtiles = dir?.listFiles { f -> f.extension == "mbtiles" }?.firstOrNull()
        return if (mbtiles != null) {
            val json = assets.open("style_offline.json").bufferedReader().readText()
                .replace("__MBTILES__", mbtiles.absolutePath)
            Style.Builder().fromJson(json)
        } else {
            Style.Builder().fromUri("https://tiles.openfreemap.org/styles/liberty")
        }
    }

    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun enableLocation(style: Style) {
        if (!hasLocationPermission()) return
        val lc = map?.locationComponent ?: return
        lc.activateLocationComponent(LocationComponentActivationOptions.builder(this, style).build())
        lc.isLocationComponentEnabled = true
        lc.cameraMode = CameraMode.TRACKING
        startUpdates()
    }

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        if (listening || !hasLocationPermission()) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 1000L, 0f, this)
        }
        listening = true
    }

    private fun setupLayers(style: Style) {
        style.addSource(GeoJsonSource("route", emptyGeo))
        style.addSource(GeoJsonSource("dest", emptyGeo))
        style.addSource(GeoJsonSource("reports", emptyGeo))
        style.addLayer(LineLayer("route-casing", "route").withProperties(
            lineColor("#0D47A1"), lineWidth(10f),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(LineLayer("route-line", "route").withProperties(
            lineColor("#42A5F5"), lineWidth(6f),
            lineCap(Property.LINE_CAP_ROUND), lineJoin(Property.LINE_JOIN_ROUND)))
        style.addLayer(CircleLayer("dest-layer", "dest").withProperties(
            circleRadius(10f), circleColor("#D32F2F"),
            circleStrokeColor(Color.WHITE), circleStrokeWidth(3f)))
        style.addLayer(CircleLayer("reports-layer", "reports").withProperties(
            circleRadius(9f),
            circleColor(Expression.toColor(Expression.get("color"))),
            circleStrokeColor(Color.WHITE), circleStrokeWidth(2f)))
    }

    // ---------- Search & routing ----------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    private fun doSearch() {
        val q = searchInput.text.toString().trim()
        if (q.isEmpty()) return
        hideKeyboard()
        lifecycleScope.launch {
            val places = withContext(Dispatchers.IO) { runCatching { GeoApi.search(q) }.getOrDefault(emptyList()) }
            results.removeAllViews()
            if (places.isEmpty()) {
                results.visibility = View.GONE
                toast(R.string.no_results)
                return@launch
            }
            places.forEach { p ->
                results.addView(TextView(this@MainActivity).apply {
                    text = p.title
                    textSize = 16f
                    setPadding(36, 26, 36, 26)
                    setOnClickListener { chooseDest(LatLng(p.lat, p.lng)) }
                })
            }
            results.visibility = View.VISIBLE
        }
    }

    private fun currentLatLng(): LatLng? {
        val l = lastLoc ?: runCatching { map?.locationComponent?.lastKnownLocation }.getOrNull()
        return l?.let { LatLng(it.latitude, it.longitude) }
    }

    private fun chooseDest(to: LatLng) {
        results.visibility = View.GONE
        searchInput.clearFocus()
        hideKeyboard()
        val from = currentLatLng()
        if (from == null) { toast(R.string.no_location); return }
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching { GeoApi.route(from.latitude, from.longitude, to.latitude, to.longitude) }.getOrNull()
            }
            if (r == null) { toast(R.string.no_route); return@launch }
            route = r
            drawRoute(r, to)
            fitRoute(r)
            routeInfo.text = summary(r.distance, r.duration)
            routeCard.visibility = View.VISIBLE
            btnStart.visibility = View.VISIBLE
        }
    }

    private fun drawRoute(r: Route, to: LatLng) {
        val coords = r.points.joinToString(",") { "[${it.longitude},${it.latitude}]" }
        val line = """{"type":"Feature","properties":{},"geometry":{"type":"LineString","coordinates":[$coords]}}"""
        val pt = """{"type":"Feature","properties":{},"geometry":{"type":"Point","coordinates":[${to.longitude},${to.latitude}]}}"""
        map?.getStyle {
            it.getSourceAs<GeoJsonSource>("route")?.setGeoJson(line)
            it.getSourceAs<GeoJsonSource>("dest")?.setGeoJson(pt)
        }
    }

    private fun fitRoute(r: Route) {
        runCatching {
            val b = LatLngBounds.Builder()
            r.points.forEach { b.include(it) }
            map?.animateCamera(CameraUpdateFactory.newLatLngBounds(b.build(), 100, 260, 100, 420), 800)
        }
    }

    private fun fmtDist(m: Double): String =
        if (m < 1000) "${((m / 10).roundToInt() * 10).coerceAtLeast(10)} متر"
        else String.format(Locale.US, "%.1f كم", m / 1000)

    private fun summary(dist: Double, dur: Double) = "${fmtDist(dist)} · ${ceil(dur / 60).toInt()} دقيقة"

    // ---------- Navigation ----------

    private fun startNav() {
        val r = route ?: return
        navigating = true
        nextIdx = 1
        announcedFar = -1
        offCount = 0
        warned.clear()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        searchCard.visibility = View.GONE
        btnStart.visibility = View.GONE
        banner.visibility = View.VISIBLE
        speedText.visibility = View.VISIBLE
        speedText.text = "0 كم/س"
        btnCancel.text = getString(R.string.end_nav)
        if (!ttsReady) toast(R.string.no_tts)
        if (r.steps.isNotEmpty()) {
            banner.text = Ar.text(r.steps.first())
            speak(Ar.text(r.steps.first()))
        }
        runCatching {
            map?.locationComponent?.apply {
                renderMode = RenderMode.GPS
                cameraMode = CameraMode.TRACKING_GPS
                zoomWhileTracking(17.0)
                tiltWhileTracking(45.0)
            }
        }
    }

    private fun clearRoute() {
        navigating = false
        route = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        map?.getStyle {
            it.getSourceAs<GeoJsonSource>("route")?.setGeoJson(emptyGeo)
            it.getSourceAs<GeoJsonSource>("dest")?.setGeoJson(emptyGeo)
        }
        routeCard.visibility = View.GONE
        banner.visibility = View.GONE
        speedText.visibility = View.GONE
        searchCard.visibility = View.VISIBLE
        btnCancel.text = getString(R.string.cancel)
        runCatching {
            map?.locationComponent?.apply {
                renderMode = RenderMode.NORMAL
                cameraMode = CameraMode.TRACKING
            }
        }
    }

    override fun onLocationChanged(loc: Location) {
        lastLoc = loc
        if (!navigating) return
        if (loc.hasAccuracy() && loc.accuracy > 60f) return
        val r = route ?: return
        val here = LatLng(loc.latitude, loc.longitude)
        speedText.text = "${(loc.speed * 3.6f).roundToInt()} كم/س"

        // Off-route -> reroute
        if (Geo.distToRoute(here, r.points) > 60.0) {
            offCount++
            val now = System.currentTimeMillis()
            if (offCount >= 3 && now - lastReroute > 10_000) reroute(here)
        } else offCount = 0

        // Steps
        if (nextIdx < r.steps.size) {
            val s = r.steps[nextIdx]
            val d = Geo.dist(here, LatLng(s.lat, s.lng))
            banner.text = Ar.text(s) + "\n" + fmtDist(d)

            var remaining = d
            for (k in nextIdx until r.steps.size) remaining += r.steps[k].distance
            val secs = remaining * (r.duration / r.distance.coerceAtLeast(1.0))
            routeInfo.text = summary(remaining, secs)

            if (s.type == "arrive") {
                if (d <= 400 && announcedFar != nextIdx) {
                    announcedFar = nextIdx
                    speak("وجهتك بعد ${((d / 50).roundToInt() * 50).coerceAtLeast(50)} متر")
                }
                if (d <= 30) {
                    speak("وصلت إلى وجهتك")
                    Toast.makeText(this, "وصلت إلى وجهتك", Toast.LENGTH_LONG).show()
                    clearRoute()
                    return
                }
            } else {
                if (d <= 400 && announcedFar != nextIdx) {
                    announcedFar = nextIdx
                    speak("بعد ${((d / 50).roundToInt() * 50).coerceAtLeast(50)} متر ${Ar.text(s)}")
                }
                if (d <= 35) {
                    speak(Ar.text(s))
                    nextIdx++
                }
            }
        }

        checkReportsAhead(here, loc)
    }

    private fun reroute(here: LatLng) {
        val to = route?.points?.lastOrNull() ?: return
        lastReroute = System.currentTimeMillis()
        offCount = 0
        speak("جاري إعادة حساب الطريق")
        lifecycleScope.launch {
            val nr = withContext(Dispatchers.IO) {
                runCatching { GeoApi.route(here.latitude, here.longitude, to.latitude, to.longitude) }.getOrNull()
            }
            if (nr != null && navigating) {
                route = nr
                nextIdx = 1
                announcedFar = -1
                drawRoute(nr, to)
            }
        }
    }

    private fun checkReportsAhead(here: LatLng, loc: Location) {
        for (rep in reports) {
            if (rep.id in warned) continue
            if (Geo.dist(here, LatLng(rep.lat, rep.lng)) > 350.0) continue
            if (loc.hasBearing() && loc.speed > 2f) {
                val t = Location("report").apply { latitude = rep.lat; longitude = rep.lng }
                val diff = abs(((loc.bearingTo(t) - loc.bearing + 540f) % 360f) - 180f)
                if (diff > 70f) continue
            }
            warned.add(rep.id)
            speak("${types[rep.type]?.first ?: "بلاغ"} أمامك")
        }
    }

    // ---------- Reports ----------

    private fun showReportSheet() {
        val sheet = BottomSheetDialog(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 60) }
        col.addView(TextView(this).apply {
            text = getString(R.string.report_title); textSize = 20f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 24)
        })
        types.forEach { (key, v) ->
            col.addView(Button(this).apply {
                text = v.first
                setOnClickListener { sheet.dismiss(); sendReport(key) }
            })
        }
        sheet.setContentView(col)
        sheet.show()
    }

    private fun sendReport(type: String) {
        val here = currentLatLng()
        if (here == null) { toast(R.string.no_location); return }
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { ReportApi.send(type, here.latitude, here.longitude) }.getOrDefault(false)
            }
            Toast.makeText(this@MainActivity, if (ok) R.string.sent else R.string.failed, Toast.LENGTH_SHORT).show()
            if (ok) refreshReports()
        }
    }

    private suspend fun refreshReports() {
        reports = withContext(Dispatchers.IO) { runCatching { ReportApi.fetch() }.getOrDefault(emptyList()) }
        val features = reports.joinToString(",") { r ->
            val color = types[r.type]?.second ?: "#757575"
            """{"type":"Feature","properties":{"color":"$color","type":"${r.type}"},"geometry":{"type":"Point","coordinates":[${r.lng},${r.lat}]}}"""
        }
        map?.getStyle { it.getSourceAs<GeoJsonSource>("reports")?.setGeoJson("""{"type":"FeatureCollection","features":[$features]}""") }
    }

    // ---------- Location listener boilerplate ----------
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    // ---------- Lifecycle ----------
    override fun onStart() {
        super.onStart(); mapView.onStart()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) { refreshReports(); delay(30_000) }
            }
        }
    }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() {
        runCatching { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this) }
        tts?.shutdown()
        mapView.onDestroy()
        super.onDestroy()
    }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
}
