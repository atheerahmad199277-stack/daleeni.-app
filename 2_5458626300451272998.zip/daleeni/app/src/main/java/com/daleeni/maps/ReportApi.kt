package com.daleeni.maps

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant

data class Report(val id: String, val type: String, val lat: Double, val lng: Double)

/** Minimal Supabase REST client. Call from a background dispatcher. */
object ReportApi {
    private val base get() = BuildConfig.SUPABASE_URL + "/rest/v1/daleeni_reports"

    private fun open(url: String, method: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 8000; readTimeout = 8000
            setRequestProperty("apikey", BuildConfig.SUPABASE_KEY)
            setRequestProperty("Authorization", "Bearer " + BuildConfig.SUPABASE_KEY)
            setRequestProperty("Content-Type", "application/json")
        }

    fun fetch(): List<Report> {
        val c = open("$base?select=id,type,lat,lng&expires_at=gt.${Instant.now()}&limit=300", "GET")
        try {
            if (c.responseCode != 200) return emptyList()
            val arr = JSONArray(c.inputStream.bufferedReader().readText())
            return (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Report(o.getString("id"), o.getString("type"), o.getDouble("lat"), o.getDouble("lng"))
            }
        } finally { c.disconnect() }
    }

    fun send(type: String, lat: Double, lng: Double): Boolean {
        val c = open(base, "POST")
        try {
            c.doOutput = true
            val body = JSONObject().put("type", type).put("lat", lat).put("lng", lng).toString()
            c.outputStream.use { it.write(body.toByteArray()) }
            return c.responseCode in 200..299
        } finally { c.disconnect() }
    }
}
