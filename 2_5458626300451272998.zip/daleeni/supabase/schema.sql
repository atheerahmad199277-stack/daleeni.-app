-- Run in Supabase SQL editor
create table public.daleeni_reports (
  id         uuid primary key default gen_random_uuid(),
  type       text not null check (type in ('checkpoint','traffic','accident','roadwork','closed','bump','camera')),
  lat        double precision not null check (lat between 28 and 38),
  lng        double precision not null check (lng between 38 and 50),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '2 hours'
);
create index daleeni_reports_expires_idx on public.daleeni_reports (expires_at);

alter table public.daleeni_reports enable row level security;
create policy "anyone can read active reports" on public.daleeni_reports for select using (expires_at > now());
create policy "anyone can insert reports"      on public.daleeni_reports for insert with check (true);
